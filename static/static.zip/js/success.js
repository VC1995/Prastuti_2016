$(document).ready(function(){
    $("#success_text").fadeIn(2900);
    $("#redirection").fadeIn(3000);
})